package com.service;

import com.bean.Subject;
import com.dao.SubjectDao;

public class SubjectService {
	
	
	 SubjectDao sd = new SubjectDao();
	    
	    public String storesubject(Subject sub) {
	        if(sd.storesubject(sub)>0) {
	            return "Subject details stored successfully";
	        }else {
	            return "Subject details didn't store";
	        }
	    }
}