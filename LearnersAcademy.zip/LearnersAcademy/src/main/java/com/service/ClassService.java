package com.service;

import com.dao.ClassDao;

import com.bean.Class;
public class ClassService {
	

	   ClassDao cd = new ClassDao();
	    
	    public String storeclass(Class cls) {
	        if(cd.storeclass(cls)>0) {
	            return "Class details stored successfully";
	        }else {
	            return "Class details didn't store";
	        }
	    }
}
